#pragma once
#include "../gta_external.hpp"

namespace utilities
{
	extern int get_frame_rate();
}