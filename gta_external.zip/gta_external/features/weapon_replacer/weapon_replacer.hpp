#include "../../gta_external.hpp"

class c_weapon_replacer
{
public:

	c_weapon_replacer();

	void replace_pistol(uint64_t hash);

	void replace_combat_pistol(uint64_t hash);

	void replace_bat(uint64_t hash);

	void replace_knife(uint64_t hash);

};