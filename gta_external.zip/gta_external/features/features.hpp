#include "../gta_external.hpp"

namespace features
{
	extern void vehicle_features(sdk::c_ped local_ped);
	extern void player_features(sdk::c_ped local_ped);
	extern void feature_thread();
}