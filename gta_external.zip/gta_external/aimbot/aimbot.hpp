 #pragma once
#include "../gta_external.hpp"

class c_aimbot
{
public:

	void do_aimbot(sdk::c_ped entity);

};